(:name ansys-mode.el
:auto-generated t
:type emacswiki
:description ""
:website "https://raw.github.com/emacsmirror/emacswiki.org/master/ansys-mode.el.gz")
