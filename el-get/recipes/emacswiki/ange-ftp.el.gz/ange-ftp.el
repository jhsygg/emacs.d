(:name ange-ftp.el
:auto-generated t
:type emacswiki
:description "transparent FTP support for GNU Emacs"
:website "https://raw.github.com/emacsmirror/emacswiki.org/master/ange-ftp.el.gz")
