(:name html-check-frag.el
:auto-generated t
:type emacswiki
:description ""
:website "https://raw.github.com/emacsmirror/emacswiki.org/master/html-check-frag.el.gz")
