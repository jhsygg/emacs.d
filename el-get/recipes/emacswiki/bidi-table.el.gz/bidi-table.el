(:name bidi-table.el
:auto-generated t
:type emacswiki
:description ""
:website "https://raw.github.com/emacsmirror/emacswiki.org/master/bidi-table.el.gz")
